import React, { useEffect } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import './FamilyTree.css';  // Add your CSS file here

const FamilyTreeComponent = () => {
  const { userId } = useParams();  // To get the current userId from the URL
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Dynamically load the FamilyTree.js script
    const script = document.createElement("script");
    script.src = "https://balkan.app/js/FamilyTree.js";
    script.async = true;
    script.onload = () => {
      if (window.FamilyTree) {  // Check if FamilyTree is defined in the window object
        initializeFamilyTree(); // Once the script is loaded, initialize the family tree
      }
    };
    document.body.appendChild(script);

    // Clean up the script when the component unmounts
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const initializeFamilyTree = () => {
    const options = getOptions();

    // Initialize the FamilyTree
    const chart = new window.FamilyTree(document.getElementById("tree"), {
      mouseScrool: window.FamilyTree.none,
      scaleInitial: options.scaleInitial,
      siblingSeparation: 120,
      template: "john",
      nodeBinding: {
        field_0: "name",
        field_1: "title",
        img_0: "img",
      },
    });

    // Disable the default behavior of opening the sidebar on click
    chart.on('click', function(sender, args) {
      // Update the URL with the clicked person's ID
      const clickedId = args.node.id;
      const newUrl = `/tree/${userId}?id=${clickedId}`;

      // Navigate to the new URL without reloading the page
      if (location.pathname + location.search !== newUrl) {
        navigate(newUrl);
      }

      // Prevent opening the sidebar by returning false
      return false;
    });

    // Load the data into the chart
    chart.load([
      { id: 1, pids: [2], name: "King George VI", img: "https://cdn.balkan.app/shared/f1.png", gender: "male" },
      { id: 2, pids: [1], name: "Queen Elizabeth", title: "The Queen Mother", img: "https://cdn.balkan.app/shared/f2.png", gender: "female" },
      { id: 3, pids: [4], mid: 2, fid: 1, name: "Queen Elizabeth II", img: "https://cdn.balkan.app/shared/f5.png", gender: "female" },
      { id: 4, pids: [3], name: "Prince Philip", title: "Duke of Edinburgh", img: "https://cdn.balkan.app/shared/f3.png", gender: "male" },
      { id: 5, mid: 2, fid: 1, name: "Princess Margaret", img: "https://cdn.balkan.app/shared/f6.png", gender: "male" },
      { id: 6, mid: 3, fid: 4, pids: [7, 8], name: "Charles", title: "Prince of Wales", img: "https://cdn.balkan.app/shared/f8.png", gender: "male" },
      { id: 7, pids: [6], name: "Diana", title: "Princess of Wales", img: "https://cdn.balkan.app/shared/f9.png", gender: "female" },
      { id: 8, pids: [6], name: "Camila", title: "Duchess of Cornwall", img: "https://cdn.balkan.app/shared/f7.png", gender: "female" },
      { id: 9, mid: 3, fid: 4, name: "Anne", title: "Princess Royal", img: "https://cdn.balkan.app/shared/f10.png", gender: "female" },
      { id: 10, mid: 3, fid: 4, name: "Prince Andrew", title: "Duke of York", img: "https://cdn.balkan.app/shared/f11.png", gender: "male" },
      { id: 11, mid: 3, fid: 4, name: "Prince Edward", title: "Earl of Wessex", img: "https://cdn.balkan.app/shared/f12.png", gender: "male" },
      { id: 12, fid: 6, mid: 7, pids: [14], name: "Prince William", title: "Duch of Cambridge", img: "https://cdn.balkan.app/shared/f14.png", gender: "male" },
      { id: 13, fid: 6, mid: 7, pids: [15], name: "Prince Harry", img: "https://cdn.balkan.app/shared/f15.png", gender: "male" },
      { id: 14, pids: [12], name: "Catherine", title: "Duchess of Cambridge", img: "https://cdn.balkan.app/shared/f13.png", gender: "female" },
      { id: 15, pids: [13], name: "Meghan Markle", img: "https://cdn.balkan.app/shared/f16.png", gender: "female" },
      { id: 16, fid: 12, mid: 14, name: "Prince George", img: "https://cdn.balkan.app/shared/f17.png", gender: "male" },
      { id: 17, fid: 12, mid: 14, name: "Prince Charlotte", img: "https://cdn.balkan.app/shared/f18.png", gender: "female" },
      { id: 18, fid: 12, mid: 14, name: "Prince Louis", img: "https://cdn.balkan.app/shared/f19.png", gender: "male" },
    ]);
  };

  const getOptions = () => {
    const searchParams = new URLSearchParams(window.location.search);
    const fit = searchParams.get("fit");
    let scaleInitial = 1;
    if (fit === "yes") {
      scaleInitial = window.FamilyTree.match.boundary;
    }
    return { scaleInitial };
  };

  return <div id="tree" style={{ width: "100%", height: "100%" }} />;
};

export default FamilyTreeComponent;
